document.addEventListener('DOMContentLoaded', () => {
  let currentCategory = 'ALL';
  let currentSearch = '';

  const articlesGrid = document.getElementById('articlesGrid');
  const btnFetch = document.getElementById('btnFetch');
  const btnDigest = document.getElementById('btnDigest');
  const searchInput = document.getElementById('searchInput');
  const navItems = document.querySelectorAll('.nav-item');
  const categoryTitle = document.getElementById('categoryTitle');
  const digestContainer = document.getElementById('digestContainer');
  const digestBody = document.getElementById('digestBody');
  const btnCloseDigest = document.getElementById('btnCloseDigest');
  const statusText = document.getElementById('statusText');

  // Gestion du menu tiroir mobile (iPhone / iPad)
  const btnMobileNav = document.getElementById('btnMobileNav');
  const sidebarNav = document.getElementById('sidebarNav');
  const sidebarOverlay = document.getElementById('sidebarOverlay');

  function closeMobileSidebar() {
    if (sidebarNav) sidebarNav.classList.remove('open');
    if (sidebarOverlay) sidebarOverlay.classList.remove('active');
  }

  function toggleMobileSidebar() {
    if (sidebarNav) sidebarNav.classList.toggle('open');
    if (sidebarOverlay) sidebarOverlay.classList.toggle('active');
  }

  if (btnMobileNav) {
    btnMobileNav.addEventListener('click', toggleMobileSidebar);
  }
  if (sidebarOverlay) {
    sidebarOverlay.addEventListener('click', closeMobileSidebar);
  }

  // Chargement des articles
  async function loadArticles() {
    articlesGrid.innerHTML = '<div class="loading-spinner">Chargement des articles...</div>';
    
    let url = `/api/articles?category=${encodeURIComponent(currentCategory)}`;
    if (currentSearch) {
      url += `&search=${encodeURIComponent(currentSearch)}`;
    }

    try {
      const response = await fetch(url);
      const data = await response.json();

      if (data.status === 'success') {
        renderArticles(data.articles);
        if (currentCategory === 'ALL' && !currentSearch) {
          document.getElementById('countAll').textContent = data.articles.length;
        }
      }
    } catch (err) {
      articlesGrid.innerHTML = '<div class="error">Impossible de charger les articles.</div>';
    }
  }

  function formatDate(raw) {
    if (!raw) return 'Sept. 2026';
    if (/^\d{4}-\d{2}-\d{2}/.test(raw)) {
      const parts = raw.split(' ');
      const dateParts = parts[0].split('-');
      const day = dateParts[2];
      const month = dateParts[1];
      const year = dateParts[0];

      let timeStr = '';
      if (parts[1]) {
        const timeParts = parts[1].split(':');
        if (timeParts.length >= 2) {
          timeStr = ` à ${timeParts[0]}h${timeParts[1]}`;
        }
      }
      return `${day}/${month}/${year}${timeStr}`;
    }
    return raw.substring(0, 16);
  }

  const articleModal = document.getElementById('articleModal');
  const btnCloseModal = document.getElementById('btnCloseModal');
  const modalTitle = document.getElementById('modalTitle');
  const modalSource = document.getElementById('modalSource');
  const modalDate = document.getElementById('modalDate');
  const modalScore = document.getElementById('modalScore');
  const modalCategory = document.getElementById('modalCategory');
  const modalContent = document.getElementById('modalContent');
  const modalExternalLink = document.getElementById('modalExternalLink');

  function openArticleModal(art) {
    modalTitle.textContent = art.title;
    modalSource.textContent = art.source;
    modalDate.textContent = `📅 ${formatDate(art.published_at)}`;
    modalScore.textContent = `⭐ Score ${art.score}/100`;
    modalCategory.textContent = `Thématique : ${art.category}`;
    modalContent.textContent = art.summary || 'Synthèse complète de la publication non disponible.';
    modalExternalLink.href = art.link;
    modalExternalLink.textContent = `Accéder au portail officiel (${art.source}) ➔`;
    articleModal.classList.remove('hidden');
  }

  btnCloseModal.addEventListener('click', () => {
    articleModal.classList.add('hidden');
  });

  articleModal.addEventListener('click', (e) => {
    if (e.target === articleModal) {
      articleModal.classList.add('hidden');
    }
  });

  function renderArticles(articles) {
    if (articles.length === 0) {
      articlesGrid.innerHTML = '<div class="no-data">Aucun article ne correspond à votre filtre.</div>';
      return;
    }

    articlesGrid.innerHTML = articles.map((art, idx) => `
      <div class="article-card">
        <div class="card-clickable" data-index="${idx}">
          <div class="card-top">
            <span class="source-tag">${escapeHtml(art.source)}</span>
            <div style="display:flex; align-items:center; gap:8px;">
              <span class="date-tag">📅 ${formatDate(art.published_at)}</span>
              <span class="score-badge">⭐ ${art.score}/100</span>
            </div>
          </div>
          <h3>${escapeHtml(art.title)}</h3>
          <p>${escapeHtml(art.summary || 'Pas de résumé disponible.')}</p>
        </div>
        <div class="card-footer">
          <button class="btn btn-secondary open-modal-btn" data-index="${idx}" style="padding:6px 12px; font-size:0.8rem;">
            📖 Lire la synthèse
          </button>
          <div style="display:flex; align-items:center; gap:12px;">
            <a href="${escapeHtml(art.link)}" target="_blank" rel="noopener" style="font-size:0.8rem;">
              Site officiel ➔
            </a>
            <button class="fav-btn ${art.is_favorite ? 'active' : ''}" data-id="${art.id}">
              ★
            </button>
          </div>
        </div>
      </div>
    `).join('');

    // Event listeners pour ouvrir la synthèse
    document.querySelectorAll('.open-modal-btn, .card-clickable').forEach(elem => {
      elem.addEventListener('click', (e) => {
        const idx = e.currentTarget.getAttribute('data-index');
        if (articles[idx]) {
          openArticleModal(articles[idx]);
        }
      });
    });

    // Event listeners pour les favoris
    document.querySelectorAll('.fav-btn').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation();
        const id = e.target.getAttribute('data-id');
        await fetch(`/api/articles/${id}/favorite`, { method: 'POST' });
        loadArticles();
      });
    });
  }

  // Navigation par catégorie
  navItems.forEach(item => {
    item.addEventListener('click', (e) => {
      navItems.forEach(n => n.classList.remove('active'));
      const btn = e.currentTarget;
      btn.classList.add('active');
      
      currentCategory = btn.getAttribute('data-category');
      categoryTitle.textContent = currentCategory === 'ALL' ? 'Dernières Tendances IA' : currentCategory;
      closeMobileSidebar();
      loadArticles();
    });
  });

  // Recherche avec debouncing
  let searchTimeout;
  searchInput.addEventListener('input', (e) => {
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(() => {
      currentSearch = e.target.value;
      loadArticles();
    }, 300);
  });

  // Action Lancer un Scan
  btnFetch.addEventListener('click', async () => {
    closeMobileSidebar();
    btnFetch.disabled = true;
    statusText.textContent = "Collecte et analyse des flux en cours...";
    
    try {
      const res = await fetch('/api/fetch', { method: 'POST' });
      const data = await res.json();
      statusText.textContent = `Scan terminé : ${data.count} nouveaux articles collectés !`;
      loadArticles();
    } catch (err) {
      statusText.textContent = "Erreur lors de la collecte.";
    } finally {
      btnFetch.disabled = false;
    }
  });

  function renderMarkdown(md) {
    if (!md) return '';
    return md
      .replace(/^### (.*$)/gim, '<h4 style="margin-top:12px; margin-bottom:4px; color:var(--accent-cyan);">$1</h4>')
      .replace(/^# (.*$)/gim, '<h3 style="margin-bottom:8px; color:var(--text-main);">$1</h3>')
      .replace(/^\> (.*$)/gim, '<blockquote style="border-left:3px solid var(--accent-purple); padding-left:10px; margin:6px 0; color:var(--text-muted);">$1</blockquote>')
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/\[(.*?)\]\((.*?)\)/g, '<a href="$2" target="_blank" rel="noopener" style="color:var(--accent-cyan); text-decoration:underline;">$1</a>')
      .replace(/\n/g, '<br>');
  }

  // Action Générer Synthèse
  btnDigest.addEventListener('click', async () => {
    closeMobileSidebar();
    btnDigest.disabled = true;
    statusText.textContent = "Génération de la synthèse IA par l'Agent...";
    
    try {
      const res = await fetch('/api/digest', { method: 'POST' });
      const data = await res.json();
      if (data.status === 'success') {
        digestBody.innerHTML = renderMarkdown(data.digest.content);
        digestContainer.classList.remove('hidden');
        statusText.textContent = "Synthèse générée avec succès !";
      }
    } catch (err) {
      statusText.textContent = "Erreur lors de la génération de la synthèse.";
    } finally {
      btnDigest.disabled = false;
    }
  });

  btnCloseDigest.addEventListener('click', () => {
    digestContainer.classList.add('hidden');
  });

  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  // Suivi de l'actualisation automatique horaire
  const syncBadge = document.getElementById('syncBadge');
  let lastSyncRecorded = '';

  async function checkSyncStatus() {
    try {
      const res = await fetch('/api/status');
      const data = await res.json();
      if (data.status === 'success') {
        if (data.total_articles !== undefined) {
          const countElem = document.getElementById('countAll');
          if (countElem) countElem.textContent = data.total_articles;
        }

        if (data.is_syncing) {
          syncBadge.textContent = '🔄 Actualisation horaire en cours...';
          syncBadge.style.color = '#38bdf8';
        } else {
          const minutesLeft = Math.ceil(data.next_sync_in_seconds / 60);
          syncBadge.textContent = `⏱️ Sync auto : ${data.last_sync_time} (prochaine dans ${minutesLeft} min)`;
          syncBadge.style.color = '#10b981';

          // Si une nouvelle synchro automatique a eu lieu, recharger la liste
          if (lastSyncRecorded && lastSyncRecorded !== data.last_sync_time) {
            loadArticles();
          }
          lastSyncRecorded = data.last_sync_time;
        }
      }
    } catch (e) {
      // Serveur temporairement indisponible
    }
  }

  // Initial load
  loadArticles();
  checkSyncStatus();

  // Vérification de statut toutes les 15 secondes
  setInterval(checkSyncStatus, 15000);
});
