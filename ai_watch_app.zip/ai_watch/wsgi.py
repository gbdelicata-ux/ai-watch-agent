"""
Fichier WSGI pour l'hébergement sur PythonAnywhere ou tout serveur WSGI (Gunicorn, uWSGI).
Permet de faire tourner l'Agent de Veille IA sans HTTPServer ni problème de ports.
"""

import os
import sys
import json
import urllib.parse
import time
from datetime import datetime
try:
    from zoneinfo import ZoneInfo
    PARIS_TZ = ZoneInfo("Europe/Paris")
except Exception:
    PARIS_TZ = None

def get_paris_time_str():
    if PARIS_TZ:
        return datetime.now(PARIS_TZ).strftime("%H:%M:%S")
    return datetime.now().strftime("%H:%M:%S")

# Définir le chemin absolu du projet
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

import watch_db
import fetcher
import analyzer

# Initialiser la base SQLite au démarrage
watch_db.init_db()
try:
    fetcher.run_fetch_cycle()
    analyzer.analyze_and_score_articles()
except Exception:
    pass

sync_state = {
    "last_sync_time": get_paris_time_str(),
    "last_sync_timestamp": time.time(),
    "interval_seconds": 3600,
    "is_syncing": False,
    "total_processed": 0
}

def application(environ, start_response):
    path = environ.get('PATH_INFO', '')
    method = environ.get('REQUEST_METHOD', 'GET').upper()
    query_string = environ.get('QUERY_STRING', '')
    query_params = urllib.parse.parse_qs(query_string)

    # 1. Gestion des requêtes CORS Preflight OPTIONS
    if method == 'OPTIONS':
        headers = [
            ('Content-Type', 'application/json; charset=utf-8'),
            ('Access-Control-Allow-Origin', '*'),
            ('Access-Control-Allow-Methods', 'GET, POST, OPTIONS'),
            ('Access-Control-Allow-Headers', 'Content-Type'),
        ]
        start_response('200 OK', headers)
        return [b'']

    # 2. Favicon & Icônes iOS
    if path in ('/favicon.ico', '/apple-touch-icon.png', '/apple-touch-icon-precomposed.png') or 'apple-touch-icon' in path:
        icon_path = os.path.join(BASE_DIR, 'static', 'apple-touch-icon.png')
        if os.path.exists(icon_path):
            with open(icon_path, 'rb') as f:
                content = f.read()
            start_response('200 OK', [('Content-Type', 'image/png'), ('Cache-Control', 'max-age=86400')])
            return [content]
        start_response('204 No Content', [])
        return [b'']

    # 3. Page d'accueil (SPA Fallback)
    if method == 'GET' and (path in ('', '/', '/index.html') or not path.startswith(('/api/', '/static/'))):
        template_path = os.path.join(BASE_DIR, 'templates', 'index.html')
        if os.path.exists(template_path):
            with open(template_path, 'rb') as f:
                content = f.read()
            start_response('200 OK', [
                ('Content-Type', 'text/html; charset=utf-8'),
                ('Cache-Control', 'no-cache')
            ])
            return [content]

    # 4. Fichiers statiques (CSS / JS / Images)
    if method == 'GET' and path.startswith('/static/'):
        rel = path[len('/static/'):]
        file_path = os.path.join(BASE_DIR, 'static', rel)
        if os.path.exists(file_path):
            content_type = 'text/plain'
            if file_path.endswith('.css'):
                content_type = 'text/css; charset=utf-8'
            elif file_path.endswith('.js'):
                content_type = 'application/javascript; charset=utf-8'
            elif file_path.endswith('.png'):
                content_type = 'image/png'
            elif file_path.endswith('.svg'):
                content_type = 'image/svg+xml'

            with open(file_path, 'rb') as f:
                content = f.read()
            start_response('200 OK', [
                ('Content-Type', content_type),
                ('Cache-Control', 'public, max-age=3600')
            ])
            return [content]
        else:
            start_response('404 Not Found', [('Content-Type', 'text/plain')])
            return [b'Fichier introuvable']

    # 5. Endpoints API GET
    if method == 'GET':
        if path == '/api/articles':
            category = query_params.get('category', ['ALL'])[0]
            search = query_params.get('search', [None])[0]
            favorites_only = (category == 'FAVORITES')
            articles = watch_db.get_articles(
                category=category if not favorites_only else None,
                search=search,
                favorites_only=favorites_only
            )
            payload = json.dumps({"status": "success", "articles": articles}).encode('utf-8')
            start_response('200 OK', [
                ('Content-Type', 'application/json; charset=utf-8'),
                ('Access-Control-Allow-Origin', '*')
            ])
            return [payload]

        elif path == '/api/digests':
            digests = watch_db.get_digests()
            payload = json.dumps({"status": "success", "digests": digests}).encode('utf-8')
            start_response('200 OK', [
                ('Content-Type', 'application/json; charset=utf-8'),
                ('Access-Control-Allow-Origin', '*')
            ])
            return [payload]

        elif path == '/api/status':
            elapsed = time.time() - sync_state["last_sync_timestamp"]
            remaining = max(0, int(sync_state["interval_seconds"] - elapsed))
            total_articles = len(watch_db.get_articles(limit=500))
            payload = json.dumps({
                "status": "success",
                "last_sync_time": sync_state["last_sync_time"],
                "interval_seconds": sync_state["interval_seconds"],
                "next_sync_in_seconds": remaining,
                "is_syncing": sync_state["is_syncing"],
                "total_articles": total_articles
            }).encode('utf-8')
            start_response('200 OK', [
                ('Content-Type', 'application/json; charset=utf-8'),
                ('Access-Control-Allow-Origin', '*')
            ])
            return [payload]

    # 6. Endpoints API POST
    if method == 'POST':
        if path == '/api/fetch':
            sync_state["is_syncing"] = True
            added_count = fetcher.run_fetch_cycle()
            analyzer.analyze_and_score_articles()
            sync_state["last_sync_time"] = get_paris_time_str()
            sync_state["last_sync_timestamp"] = time.time()
            sync_state["is_syncing"] = False
            payload = json.dumps({"status": "success", "count": added_count}).encode('utf-8')
            start_response('200 OK', [
                ('Content-Type', 'application/json; charset=utf-8'),
                ('Access-Control-Allow-Origin', '*')
            ])
            return [payload]

        elif path == '/api/digest':
            digest = analyzer.generate_daily_digest()
            payload = json.dumps({"status": "success", "digest": digest}).encode('utf-8')
            start_response('200 OK', [
                ('Content-Type', 'application/json; charset=utf-8'),
                ('Access-Control-Allow-Origin', '*')
            ])
            return [payload]

        elif path.startswith('/api/articles/') and path.endswith('/favorite'):
            try:
                article_id = int(path.split('/')[3])
                watch_db.toggle_favorite(article_id)
                payload = json.dumps({"status": "success"}).encode('utf-8')
                start_response('200 OK', [
                    ('Content-Type', 'application/json; charset=utf-8'),
                    ('Access-Control-Allow-Origin', '*')
                ])
                return [payload]
            except (ValueError, IndexError):
                start_response('400 Bad Request', [('Content-Type', 'application/json')])
                return [b'{"status": "error", "message": "ID invalide"}']

    # 7. Route 404
    start_response('404 Not Found', [('Content-Type', 'application/json; charset=utf-8')])
    return [b'{"status": "error", "message": "Endpoint non trouve"}']

if __name__ == '__main__':
    from wsgiref.simple_server import make_server
    port = 8099
    print(f"Serveur de test WSGI actif sur http://localhost:{port}")
    server = make_server('', port, application)
    server.serve_forever()
