"""
Fichier WSGI pour l'hébergement sur PythonAnywhere ou tout serveur WSGI (Gunicorn, uWSGI, Render).
"""

import os
import sys
import json
import urllib.parse
import time
import threading
from datetime import datetime
try:
    from zoneinfo import ZoneInfo
    PARIS_TZ = ZoneInfo("Europe/Paris")
except Exception:
    PARIS_TZ = None

def get_now_paris():
    return datetime.now(PARIS_TZ) if PARIS_TZ else datetime.now()

def get_paris_time_str():
    return get_now_paris().strftime("%H:%M:%S")

def get_paris_date_str():
    return get_now_paris().strftime("%Y-%m-%d")

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

import watch_db
import fetcher
import analyzer

REFRESH_INTERVAL_SECONDS = 1800
sync_state = {
    "last_sync_time": get_paris_time_str(),
    "last_sync_date": "",
    "last_sync_timestamp": time.time(),
    "interval_seconds": REFRESH_INTERVAL_SECONDS,
    "is_syncing": False,
    "total_processed": 0
}
sync_lock = threading.Lock()

watch_db.init_db()

def ensure_fresh_daily_local():
    today_str = get_paris_date_str()
    if sync_state["last_sync_date"] == today_str and not watch_db.needs_daily_refresh(today_str):
        return
    with sync_lock:
        try:
            fetcher.sync_daily_base_instant()
            analyzer.analyze_and_score_articles()
            sync_state["last_sync_date"] = today_str
            sync_state["last_sync_time"] = get_paris_time_str()
            sync_state["last_sync_timestamp"] = time.time()
        except Exception:
            pass

ensure_fresh_daily_local()

def application(environ, start_response):
    path = environ.get('PATH_INFO', '')
    method = environ.get('REQUEST_METHOD', 'GET').upper()
    query_string = environ.get('QUERY_STRING', '')
    query_params = urllib.parse.parse_qs(query_string)

    if method == 'OPTIONS':
        headers = [
            ('Content-Type', 'application/json; charset=utf-8'),
            ('Access-Control-Allow-Origin', '*'),
            ('Access-Control-Allow-Methods', 'GET, POST, OPTIONS'),
            ('Access-Control-Allow-Headers', 'Content-Type, Cache-Control, Pragma'),
        ]
        start_response('200 OK', headers)
        return [b'']

    if path in ('/favicon.ico', '/apple-touch-icon.png', '/apple-touch-icon-precomposed.png') or 'apple-touch-icon' in path:
        icon_path = os.path.join(BASE_DIR, 'static', 'apple-touch-icon.png')
        if os.path.exists(icon_path):
            with open(icon_path, 'rb') as f:
                content = f.read()
            start_response('200 OK', [('Content-Type', 'image/png'), ('Cache-Control', 'max-age=86400')])
            return [content]
        start_response('204 No Content', [])
        return [b'']

    if method == 'GET' and (path in ('', '/', '/index.html') or not path.startswith(('/api/', '/static/'))):
        template_path = os.path.join(BASE_DIR, 'templates', 'index.html')
        if os.path.exists(template_path):
            with open(template_path, 'rb') as f:
                content = f.read()
            start_response('200 OK', [
                ('Content-Type', 'text/html; charset=utf-8'),
                ('Cache-Control', 'no-cache, no-store, must-revalidate')
            ])
            return [content]

    if method == 'GET' and path.startswith('/static/'):
        rel = path[len('/static/'):]
        file_path = os.path.join(BASE_DIR, 'static', rel)
        if os.path.exists(file_path):
            content_type = 'text/plain'
            if file_path.endswith('.css'):
                content_type = 'text/css; charset=utf-8'
            elif file_path.endswith('.js'):
                content_type = 'application/javascript; charset=utf-8'
            elif file_path.endswith('.png'):
                content_type = 'image/png'
            elif file_path.endswith('.svg'):
                content_type = 'image/svg+xml'

            with open(file_path, 'rb') as f:
                content = f.read()
            start_response('200 OK', [
                ('Content-Type', content_type),
                ('Cache-Control', 'no-cache, no-store, must-revalidate')
            ])
            return [content]
        start_response('404 Not Found', [('Content-Type', 'text/plain')])
        return [b'Fichier introuvable']

    json_headers = [
        ('Content-Type', 'application/json; charset=utf-8'),
        ('Cache-Control', 'no-cache, no-store, must-revalidate'),
        ('Pragma', 'no-cache'),
        ('Expires', '0'),
        ('Access-Control-Allow-Origin', '*')
    ]

    if method == 'GET':
        if path == '/api/articles':
            ensure_fresh_daily_local()
            today_str = get_paris_date_str()
            category = query_params.get('category', ['ALL'])[0]
            search = query_params.get('search', [None])[0]
            favorites_only = (category == 'FAVORITES')
            articles = watch_db.get_articles(
                category=category if not favorites_only else None,
                search=search,
                favorites_only=favorites_only,
                limit=250
            )
            counts = watch_db.get_category_counts(today_str)
            payload = json.dumps({
                "status": "success",
                "today_date": today_str,
                "counts": counts,
                "articles": articles
            }).encode('utf-8')
            start_response('200 OK', json_headers)
            return [payload]

        elif path == '/api/digests':
            digests = watch_db.get_digests()
            payload = json.dumps({"status": "success", "digests": digests}).encode('utf-8')
            start_response('200 OK', json_headers)
            return [payload]

        elif path == '/api/status':
            ensure_fresh_daily_local()
            today_str = get_paris_date_str()
            elapsed = time.time() - sync_state["last_sync_timestamp"]
            remaining = max(0, int(sync_state["interval_seconds"] - elapsed))
            counts = watch_db.get_category_counts(today_str)
            payload = json.dumps({
                "status": "success",
                "today_date": today_str,
                "last_sync_time": sync_state["last_sync_time"],
                "interval_seconds": sync_state["interval_seconds"],
                "next_sync_in_seconds": remaining,
                "is_syncing": sync_state["is_syncing"],
                "total_articles": counts.get("ALL", 0),
                "sources_count": len(fetcher.RSS_FEEDS),
                "counts": counts
            }).encode('utf-8')
            start_response('200 OK', json_headers)
            return [payload]

    if method == 'POST':
        if path == '/api/fetch':
            sync_state["is_syncing"] = True
            added_count = fetcher.run_fetch_cycle()
            analyzer.analyze_and_score_articles()
            sync_state["last_sync_time"] = get_paris_time_str()
            sync_state["last_sync_date"] = get_paris_date_str()
            sync_state["last_sync_timestamp"] = time.time()
            sync_state["is_syncing"] = False
            payload = json.dumps({
                "status": "success",
                "count": added_count,
                "last_sync_time": sync_state["last_sync_time"]
            }).encode('utf-8')
            start_response('200 OK', json_headers)
            return [payload]

        elif path == '/api/digest':
            digest = analyzer.generate_daily_digest()
            payload = json.dumps({"status": "success", "digest": digest}).encode('utf-8')
            start_response('200 OK', json_headers)
            return [payload]

        elif path.startswith('/api/articles/') and path.endswith('/favorite'):
            try:
                article_id = int(path.split('/')[3])
                watch_db.toggle_favorite(article_id)
                payload = json.dumps({"status": "success"}).encode('utf-8')
                start_response('200 OK', json_headers)
                return [payload]
            except (ValueError, IndexError):
                start_response('400 Bad Request', json_headers)
                return [json.dumps({"status": "error"}).encode('utf-8')]

    start_response('404 Not Found', json_headers)
    return [json.dumps({"status": "error", "message": "Endpoint inconnu"}).encode('utf-8')]
