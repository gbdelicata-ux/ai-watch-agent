"""
Serveur HTTP Backend Python pour l'Agent de Veille Technologique IA.
"""

from http.server import HTTPServer, SimpleHTTPRequestHandler
import json
import urllib.parse
import os
import threading
import time
from datetime import datetime
try:
    from zoneinfo import ZoneInfo
    PARIS_TZ = ZoneInfo("Europe/Paris")
except Exception:
    PARIS_TZ = None

def get_now_paris():
    return datetime.now(PARIS_TZ) if PARIS_TZ else datetime.now()

def get_paris_time_str():
    return get_now_paris().strftime("%H:%M:%S")

def get_paris_date_str():
    return get_now_paris().strftime("%Y-%m-%d")

import watch_db
import fetcher
import analyzer

PORT = int(os.environ.get("PORT", 8099))
BASE_DIR = os.path.dirname(__file__)
REFRESH_INTERVAL_SECONDS = 1800  # Actualisation automatique toutes les 30 minutes

sync_state = {
    "last_sync_time": get_paris_time_str(),
    "last_sync_date": "",
    "last_sync_timestamp": time.time(),
    "interval_seconds": REFRESH_INTERVAL_SECONDS,
    "is_syncing": False,
    "total_processed": 0
}
sync_lock = threading.Lock()

def ensure_fresh_daily_local():
    """Garantit en < 10ms (sans appel réseau bloquant) que les articles du jour sont prêts."""
    today_str = get_paris_date_str()
    if sync_state["last_sync_date"] == today_str and not watch_db.needs_daily_refresh(today_str):
        return
    with sync_lock:
        try:
            fetcher.sync_daily_base_instant()
            analyzer.analyze_and_score_articles()
            sync_state["last_sync_date"] = today_str
            sync_state["last_sync_time"] = get_paris_time_str()
            sync_state["last_sync_timestamp"] = time.time()
        except Exception as e:
            print(f"⚠️ Erreur synchro locale : {e}")

def auto_refresh_worker():
    """Tâche de fond non-bloquante exécutant la collecte RSS régulièrement."""
    time.sleep(2)
    while True:
        try:
            sync_state["is_syncing"] = True
            count = fetcher.run_fetch_cycle()
            analyzer.analyze_and_score_articles()
            sync_state["last_sync_time"] = get_paris_time_str()
            sync_state["last_sync_date"] = get_paris_date_str()
            sync_state["last_sync_timestamp"] = time.time()
            sync_state["total_processed"] += count
        except Exception:
            pass
        finally:
            sync_state["is_syncing"] = False
        time.sleep(REFRESH_INTERVAL_SECONDS)

class AIWatchHandler(SimpleHTTPRequestHandler):

    def _set_json_headers(self, status=200):
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
        self.send_header('Pragma', 'no-cache')
        self.send_header('Expires', '0')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type, Cache-Control, Pragma')
        self.end_headers()

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type, Cache-Control, Pragma')
        self.end_headers()

    def do_GET(self):
        parsed_url = urllib.parse.urlparse(self.path)
        path = parsed_url.path
        query_params = urllib.parse.parse_qs(parsed_url.query)

        if path in ('/favicon.ico', '/apple-touch-icon.png', '/apple-touch-icon-precomposed.png') or 'apple-touch-icon' in path:
            icon_path = os.path.join(BASE_DIR, 'static', 'apple-touch-icon.png')
            if os.path.exists(icon_path):
                self.send_response(200)
                self.send_header('Content-Type', 'image/png')
                self.end_headers()
                with open(icon_path, 'rb') as f:
                    self.wfile.write(f.read())
                return
            self.send_response(204)
            self.end_headers()
            return

        if path == '/' or path == '/index.html' or not path.startswith(('/api/', '/static/')):
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
            self.end_headers()
            template_path = os.path.join(BASE_DIR, 'templates', 'index.html')
            with open(template_path, 'rb') as f:
                self.wfile.write(f.read())
            return

        elif path.startswith('/static/'):
            relative_path = path[len('/static/'):]
            file_path = os.path.join(BASE_DIR, 'static', relative_path)
            if os.path.exists(file_path):
                self.send_response(200)
                if file_path.endswith('.css'):
                    self.send_header('Content-Type', 'text/css; charset=utf-8')
                    self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
                elif file_path.endswith('.js'):
                    self.send_header('Content-Type', 'application/javascript; charset=utf-8')
                    self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
                elif file_path.endswith('.png'):
                    self.send_header('Content-Type', 'image/png')
                elif file_path.endswith('.svg'):
                    self.send_header('Content-Type', 'image/svg+xml')
                self.end_headers()
                with open(file_path, 'rb') as f:
                    self.wfile.write(f.read())
                return

        elif path == '/api/articles':
            ensure_fresh_daily_local()
            today_str = get_paris_date_str()
            category = query_params.get('category', ['ALL'])[0]
            search = query_params.get('search', [None])[0]
            favorites_only = (category == 'FAVORITES')
            
            articles = watch_db.get_articles(
                category=category if not favorites_only else None,
                search=search,
                favorites_only=favorites_only,
                limit=250
            )
            counts = watch_db.get_category_counts(today_str)
            self._set_json_headers(200)
            self.wfile.write(json.dumps({
                "status": "success",
                "today_date": today_str,
                "counts": counts,
                "articles": articles
            }).encode('utf-8'))
            return

        elif path == '/api/digests':
            digests = watch_db.get_digests()
            self._set_json_headers(200)
            self.wfile.write(json.dumps({"status": "success", "digests": digests}).encode('utf-8'))
            return

        elif path == '/api/status':
            ensure_fresh_daily_local()
            today_str = get_paris_date_str()
            elapsed = time.time() - sync_state["last_sync_timestamp"]
            remaining = max(0, int(sync_state["interval_seconds"] - elapsed))
            counts = watch_db.get_category_counts(today_str)
            
            payload = {
                "status": "success",
                "today_date": today_str,
                "last_sync_time": sync_state["last_sync_time"],
                "interval_seconds": sync_state["interval_seconds"],
                "next_sync_in_seconds": remaining,
                "is_syncing": sync_state["is_syncing"],
                "total_articles": counts.get("ALL", 0),
                "sources_count": len(fetcher.RSS_FEEDS),
                "counts": counts
            }
            self._set_json_headers(200)
            self.wfile.write(json.dumps(payload).encode('utf-8'))
            return

        self._set_json_headers(404)
        self.wfile.write(json.dumps({"status": "error", "message": "Non trouvé"}).encode('utf-8'))

    def do_POST(self):
        parsed_url = urllib.parse.urlparse(self.path)
        path = parsed_url.path

        if path == '/api/fetch':
            sync_state["is_syncing"] = True
            added_count = fetcher.run_fetch_cycle()
            analyzer.analyze_and_score_articles()
            sync_state["last_sync_time"] = get_paris_time_str()
            sync_state["last_sync_date"] = get_paris_date_str()
            sync_state["last_sync_timestamp"] = time.time()
            sync_state["is_syncing"] = False
            self._set_json_headers(200)
            self.wfile.write(json.dumps({
                "status": "success",
                "count": added_count,
                "last_sync_time": sync_state["last_sync_time"]
            }).encode('utf-8'))
            return

        elif path == '/api/digest':
            digest = analyzer.generate_daily_digest()
            self._set_json_headers(200)
            self.wfile.write(json.dumps({"status": "success", "digest": digest}).encode('utf-8'))
            return

        elif path.startswith('/api/articles/') and path.endswith('/favorite'):
            try:
                article_id = int(path.split('/')[3])
                watch_db.toggle_favorite(article_id)
                self._set_json_headers(200)
                self.wfile.write(json.dumps({"status": "success"}).encode('utf-8'))
                return
            except (ValueError, IndexError):
                self._set_json_headers(400)
                return

        self._set_json_headers(404)

class HTTPServerReuse(HTTPServer):
    allow_reuse_address = True

def run_server():
    watch_db.init_db()
    # Initialisation locale instantanée (< 15ms) pour ouvrir le port HTTP immédiatement sur Render/Mac
    ensure_fresh_daily_local()

    worker = threading.Thread(target=auto_refresh_worker, daemon=True)
    worker.start()

    server_address = ('', PORT)
    httpd = HTTPServerReuse(server_address, AIWatchHandler)
    print(f"🚀 Agent de Veille IA démarré immédiatement sur http://localhost:{PORT} ({len(fetcher.RSS_FEEDS)} sources actives)")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nArrêt de l'Agent de Veille.")
        httpd.server_close()

if __name__ == '__main__':
    run_server()
