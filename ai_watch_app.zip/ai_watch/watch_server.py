"""
Serveur HTTP Backend Python pour l'Agent de Veille Technologique IA.
"""

from http.server import HTTPServer, SimpleHTTPRequestHandler
import json
import urllib.parse
import os
import threading
import time
from datetime import datetime
try:
    from zoneinfo import ZoneInfo
    PARIS_TZ = ZoneInfo("Europe/Paris")
except Exception:
    PARIS_TZ = None

def get_paris_time_str():
    if PARIS_TZ:
        return datetime.now(PARIS_TZ).strftime("%H:%M:%S")
    return datetime.now().strftime("%H:%M:%S")

import watch_db
import fetcher
import analyzer

PORT = int(os.environ.get("PORT", 8099))
BASE_DIR = os.path.dirname(__file__)
REFRESH_INTERVAL_SECONDS = 3600  # Actualisation toutes les heures (60 minutes)

sync_state = {
    "last_sync_time": get_paris_time_str(),
    "last_sync_timestamp": time.time(),
    "interval_seconds": REFRESH_INTERVAL_SECONDS,
    "is_syncing": False,
    "total_processed": 0
}

def auto_refresh_worker():
    """Tâche de fond exécutant une synchronisation de la veille toutes les heures."""
    print("⏱️ Planificateur de veille activé : Actualisation automatique toutes les heures (3600s).")
    while True:
        try:
            print(f"⏰ [{get_paris_time_str()}] Démarrage de l'actualisation horaire...")
            sync_state["is_syncing"] = True
            count = fetcher.run_fetch_cycle()
            analyzer.analyze_and_score_articles()
            sync_state["last_sync_time"] = get_paris_time_str()
            sync_state["last_sync_timestamp"] = time.time()
            sync_state["total_processed"] += count
            print(f"✅ Actualisation horaire terminée avec succès (+{count} articles).")
        except Exception as e:
            print(f"⚠️ Erreur lors de l'actualisation automatique horaire : {e}")
        finally:
            sync_state["is_syncing"] = False
        
        time.sleep(REFRESH_INTERVAL_SECONDS)

class AIWatchHandler(SimpleHTTPRequestHandler):

    def _set_json_headers(self, status=200):
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
        self.send_header('Pragma', 'no-cache')
        self.send_header('Expires', '0')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()

    def do_GET(self):
        parsed_url = urllib.parse.urlparse(self.path)
        path = parsed_url.path
        query_params = urllib.parse.parse_qs(parsed_url.query)

        # Favicon et icônes iOS Apple
        if path in ('/favicon.ico', '/apple-touch-icon.png', '/apple-touch-icon-precomposed.png') or 'apple-touch-icon' in path:
            icon_path = os.path.join(BASE_DIR, 'static', 'apple-touch-icon.png')
            if os.path.exists(icon_path):
                self.send_response(200)
                self.send_header('Content-Type', 'image/png')
                self.end_headers()
                with open(icon_path, 'rb') as f:
                    self.wfile.write(f.read())
                return
            self.send_response(204)
            self.end_headers()
            return

        # Page d'accueil et routes applicatives (SPA fallback)
        if path == '/' or path == '/index.html' or not path.startswith(('/api/', '/static/')):
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.end_headers()
            template_path = os.path.join(BASE_DIR, 'templates', 'index.html')
            with open(template_path, 'rb') as f:
                self.wfile.write(f.read())
            return

        # Fichiers statiques (CSS / JS / Images)
        elif path.startswith('/static/'):
            relative_path = path[len('/static/'):]
            file_path = os.path.join(BASE_DIR, 'static', relative_path)
            if os.path.exists(file_path):
                self.send_response(200)
                if file_path.endswith('.css'):
                    self.send_header('Content-Type', 'text/css; charset=utf-8')
                    self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
                elif file_path.endswith('.js'):
                    self.send_header('Content-Type', 'application/javascript; charset=utf-8')
                    self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
                elif file_path.endswith('.png'):
                    self.send_header('Content-Type', 'image/png')
                elif file_path.endswith('.svg'):
                    self.send_header('Content-Type', 'image/svg+xml')
                self.end_headers()
                with open(file_path, 'rb') as f:
                    self.wfile.write(f.read())
                return

        # Endpoints API REST
        elif path == '/api/articles':
            category = query_params.get('category', ['ALL'])[0]
            search = query_params.get('search', [None])[0]
            favorites_only = (category == 'FAVORITES')
            
            articles = watch_db.get_articles(
                category=category if not favorites_only else None,
                search=search,
                favorites_only=favorites_only
            )
            self._set_json_headers(200)
            self.wfile.write(json.dumps({"status": "success", "articles": articles}).encode('utf-8'))
            return

        elif path == '/api/digests':
            digests = watch_db.get_digests()
            self._set_json_headers(200)
            self.wfile.write(json.dumps({"status": "success", "digests": digests}).encode('utf-8'))
            return

        elif path == '/api/status':
            elapsed = time.time() - sync_state["last_sync_timestamp"]
            remaining = max(0, int(sync_state["interval_seconds"] - elapsed))
            articles = watch_db.get_articles(limit=1)
            total_articles = len(watch_db.get_articles(limit=500))
            
            payload = {
                "status": "success",
                "last_sync_time": sync_state["last_sync_time"],
                "interval_seconds": sync_state["interval_seconds"],
                "next_sync_in_seconds": remaining,
                "is_syncing": sync_state["is_syncing"],
                "total_articles": total_articles
            }
            self._set_json_headers(200)
            self.wfile.write(json.dumps(payload).encode('utf-8'))
            return

        self._set_json_headers(404)
        self.wfile.write(json.dumps({"status": "error", "message": "Non trouvé"}).encode('utf-8'))

    def do_POST(self):
        parsed_url = urllib.parse.urlparse(self.path)
        path = parsed_url.path

        if path == '/api/fetch':
            sync_state["is_syncing"] = True
            added_count = fetcher.run_fetch_cycle()
            analyzer.analyze_and_score_articles()
            sync_state["last_sync_time"] = get_paris_time_str()
            sync_state["last_sync_timestamp"] = time.time()
            sync_state["is_syncing"] = False
            self._set_json_headers(200)
            self.wfile.write(json.dumps({"status": "success", "count": added_count}).encode('utf-8'))
            return

        elif path == '/api/digest':
            digest = analyzer.generate_daily_digest()
            self._set_json_headers(200)
            self.wfile.write(json.dumps({"status": "success", "digest": digest}).encode('utf-8'))
            return

        elif path.startswith('/api/articles/') and path.endswith('/favorite'):
            try:
                article_id = int(path.split('/')[3])
                watch_db.toggle_favorite(article_id)
                self._set_json_headers(200)
                self.wfile.write(json.dumps({"status": "success"}).encode('utf-8'))
                return
            except (ValueError, IndexError):
                self._set_json_headers(400)
                return

        self._set_json_headers(404)

class HTTPServerReuse(HTTPServer):
    allow_reuse_address = True

def run_server():
    watch_db.init_db()

    # Exécution immédiate de la veille au lancement du serveur
    try:
        print("🚀 Exécution de la collecte initiale au démarrage du serveur...")
        count = fetcher.run_fetch_cycle()
        analyzer.analyze_and_score_articles()
        sync_state["last_sync_time"] = get_paris_time_str()
        sync_state["last_sync_timestamp"] = time.time()
        print(f"✅ Collecte initiale terminée ({count} articles).")
    except Exception as e:
        print(f"⚠️ Erreur lors de la collecte initiale : {e}")

    # Démarrage du thread d'actualisation automatique horaire (3600s)
    worker = threading.Thread(target=auto_refresh_worker, daemon=True)
    worker.start()

    server_address = ('', PORT)
    httpd = HTTPServerReuse(server_address, AIWatchHandler)
    print(f"🚀 Agent de Veille IA démarré avec succès sur http://localhost:{PORT} (Auto-sync: 1h)")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nArrêt de l'Agent de Veille.")
        httpd.server_close()

if __name__ == '__main__':
    run_server()
