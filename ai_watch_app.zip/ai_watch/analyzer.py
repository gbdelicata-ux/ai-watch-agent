"""
Moteur d'analyse, scoring et génération de synthèses / digests de veille IA.
"""

import watch_db

KEYWORD_CATEGORIES = {
    "✨ Actualité de Google & Gemini": ["google", "gemini", "gemma", "deepmind", "workspace", "tpu", "veo", "imagen", "alphafold", "sundar pichai", "hassabis"],
    "🇺🇸 Intelligence Artificielle aux USA": ["usa", "états-unis", "techcrunch", "venturebeat", "wired", "technology review", "mit", "the verge", "ars technica", "the batch", "anthropic", "silicon valley", "san francisco", "us ai"],
    "🤖 Robots Humanoïdes": ["humanoïde", "humanoide", "robot", "robotique", "optimus", "figure 02", "figure", "unitree", "boston dynamics", "embodied", "manipulateur"],
    "⚛️ Informatique Quantique": ["quantique", "quantum", "qubit", "pasqal", "quandela", "alice & bob", "suprématie quantique", "processeur quantique", "intrication", "qpu"],
    "🇫🇷 Écosystème FR & Recherche": ["inria", "cnrs", "france", "mistral", "souveraineté", "eu ai act", "cnil", "usine digitale", "usine-digitale"],
    "📰 Actus & Décryptages": ["brief ia", "le fil ia", "actualité", "analyse", "dossier", "décryptage"],
    "🛠️ Outils & Applications": ["outil", "outils", "aixploria", "bdm", "générateur", "productivité", "prompt", "code"],
    "💼 Entreprise & Souveraineté": ["ia news", "entreprise", "supply chain", "business", "industrie"],
    "🧬 Modèles & Recherche Mondiale": ["arxiv", "paper", "claude", "reasoning", "llm", "transformer", "benchmark", "deep learning", "recherche mondiale"]
}

HIGH_IMPACT_KEYWORDS = [
    "mistral", "inria", "gemini", "deepmind", "eu ai act", "souveraineté", 
    "multimodal", "agent", "reasoning", "quantique", "quantum", "qubit", "pasqal", 
    "quandela", "robot", "humanoïde", "optimus", "figure", "techcrunch", "venturebeat",
    "anthropic", "openai", "wired", "technology review"
]

def analyze_and_score_articles():
    articles = watch_db.get_articles(limit=200)
    conn = watch_db.get_connection()
    
    updated_count = 0
    for article in articles:
        text = (article["title"] + " " + (article["summary"] or "") + " " + article["source"]).lower()
        score = 50
        detected_category = article["category"]

        # 1. Ajustement de catégorie selon mots-clés
        for cat, keywords in KEYWORD_CATEGORIES.items():
            if any(kw in text for kw in keywords):
                detected_category = cat
                break

        # 2. Calcul du score d'impact avec bonus pour les médias français majeurs
        if article["source"] in ["Brief IA", "Inria - Actus IA", "Le Fil IA", "Mistral AI", "Usine Digitale - IA"]:
            score += 15

        for kw in HIGH_IMPACT_KEYWORDS:
            if kw in text:
                score += 10

        if "agent" in text or "souveraineté" in text:
            score += 10

        score = min(100, max(10, score))

        conn.execute(
            "UPDATE articles SET category = ?, score = ? WHERE id = ?",
            (detected_category, score, article["id"])
        )
        updated_count += 1

    conn.commit()
    conn.close()
    return updated_count

def generate_daily_digest():
    """Génère un résumé des meilleures pépites de la veille IA."""
    analyze_and_score_articles()
    top_articles = watch_db.get_articles(limit=5)
    
    if not top_articles:
        return "Aucune actualité disponible pour générer la synthèse."

    digest_lines = [
        "# 🤖 Synthèse Quotidienne de Veille IA",
        "Voici les avancées majeurs et publications prioritaires identifiées par votre Agent de Veille :\n"
    ]

    for idx, art in enumerate(top_articles, 1):
        digest_lines.append(f"### {idx}. {art['title']} (Score : {art['score']}/100)")
        digest_lines.append(f"**Source :** {art['source']} | **Catégorie :** {art['category']}")
        digest_lines.append(f"> {art['summary'] or 'Résumé indisponible.'}")
        digest_lines.append(f"🔗 [Lire l'article complet]({art['link']})\n")

    content = "\n".join(digest_lines)
    title = f"Bulletin de Veille IA du {top_articles[0]['published_at'] or 'Jour'}"
    
    digest_id = watch_db.save_digest(title, content)
    return {"id": digest_id, "title": title, "content": content}

if __name__ == "__main__":
    count = analyze_and_score_articles()
    print(f"Scoring et catégorisation effectués sur {count} articles.")
    digest = generate_daily_digest()
    print("Bulletin généré avec succès !")
