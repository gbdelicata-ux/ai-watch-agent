"""
Moteur d'analyse, scoring et génération de synthèses / digests de veille IA.
"""

import watch_db

VALID_CATEGORIES = {
    "✨ Actualité de Google & Gemini",
    "🤖 Robots Humanoïdes",
    "⚛️ Informatique Quantique",
    "🇺🇸 Intelligence Artificielle aux USA",
    "🇫🇷 Écosystème FR & Recherche",
    "📰 Actus & Décryptages",
    "🛠️ Outils & Applications",
    "💼 Entreprise & Souveraineté",
    "🧬 Modèles & Recherche Mondiale"
}

# Ordre de priorité du plus spécifique au plus général pour les flux RSS bruts
KEYWORD_CATEGORIES = {
    "⚛️ Informatique Quantique": [
        "quantique", "quantum", "qubit", "pasqal", "quandela", "alice & bob",
        "willow", "majorana", "heron", "qiskit", "qpu", "post-quantique"
    ],
    "🤖 Robots Humanoïdes": [
        "humanoïde", "humanoide", "robot", "robotique", "optimus", "figure 02",
        "helix", "unitree", "boston dynamics", "atlas", "1x", "neo gamma",
        "apptronik", "enchanted tools", "wandercraft", "bipède"
    ],
    "✨ Actualité de Google & Gemini": [
        "gemini", "gemma", "deepmind", "vertex ai", "tpu", "veo 2", "imagen 3",
        "alphafold", "notebooklm", "project astra", "sundar pichai", "hassabis"
    ],
    "🧬 Modèles & Recherche Mondiale": [
        "arxiv", "hugging face", "latent space", "simon willison", "raschka",
        "import ai", "marktechpost", "mamba", "deepseek", "qwen", "smollm",
        "open-weight", "swe-bench", "grpo", "mlx"
    ],
    "🇺🇸 Intelligence Artificielle aux USA": [
        "openai", "anthropic", "meta ai", "llama 4", "nvidia", "blackwell",
        "rubin", "grok", "xai", "perplexity", "techcrunch", "venturebeat",
        "wired", "technology review", "the verge", "ars technica", "the batch",
        "the decoder", "silicon valley"
    ],
    "🇫🇷 Écosystème FR & Recherche": [
        "inria", "cnrs", "mistral", "kyutai", "jean zay", "eu ai act", "cnil",
        "ap-hp", "souveraineté numérique"
    ],
    "💼 Entreprise & Souveraineté": [
        "maddyness", "journal du net", "jdn", "ia news", "cac 40", "secnumcloud",
        "ovhcloud", "scaleway", "levée de fonds", "amiad", "salaires"
    ],
    "🛠️ Outils & Applications": [
        "frandroid", "01net", "aixploria", "bdm", "blog du modérateur",
        "cursor", "windsurf", "vibe coding", "n8n", "flux.1", "elevenlabs",
        "suno", "no-code", "tutoriel"
    ],
    "📰 Actus & Décryptages": [
        "brief ia", "le fil ia", "siècle digital", "les numériques",
        "comparatif", "baromètre", "décryptage", "analyse"
    ]
}

HIGH_IMPACT_KEYWORDS = [
    "gemini 2.5", "gemini", "gemma 3", "deepmind", "mistral", "inria", "cnrs",
    "claude 3.7", "openai o3", "operator", "llama 4", "deepseek", "blackwell",
    "quantique", "quantum", "qubit", "pasqal", "quandela", "alice & bob", "willow",
    "majorana", "robot", "humanoïde", "optimus", "figure 02", "atlas", "neo gamma",
    "eu ai act", "souveraineté", "agent", "mcp", "multimodal", "raisonnement"
]

PREMIUM_SOURCES = {
    "Google AI Blog", "Google DeepMind Blog", "Google Cloud AI",
    "Brief IA", "Le Fil IA", "Siècle Digital - IA", "Frandroid - IA",
    "Les Numériques - IA", "Usine Digitale - IA", "Maddyness - IA & DeepTech",
    "Inria - Actus IA", "CNRS Le Journal - IA", "OpenAI News", "Anthropic Research",
    "Hugging Face Blog", "Latent Space (AI Eng)", "The Quantum Insider", "The Robot Report"
}

def analyze_and_score_articles():
    articles = watch_db.get_articles(limit=300)
    conn = watch_db.get_connection()
    
    updated_count = 0
    for article in articles:
        text = (article["title"] + " " + (article["summary"] or "") + " " + article["source"]).lower()
        score = 55
        current_cat = article["category"]

        # Si la catégorie n'est pas déjà définie dans les 9 thématiques, la détecter automatiquement
        if current_cat not in VALID_CATEGORIES:
            detected_category = "📰 Actus & Décryptages"
            for cat, keywords in KEYWORD_CATEGORIES.items():
                if any(kw in text for kw in keywords):
                    detected_category = cat
                    break
        else:
            detected_category = current_cat

        # Calcul du score de pertinence et d'impact technologique
        if article["source"] in PREMIUM_SOURCES:
            score += 12

        matched_kw = 0
        for kw in HIGH_IMPACT_KEYWORDS:
            if kw in text:
                matched_kw += 1
        score += min(28, matched_kw * 8)

        if any(w in text for w in ["agent", "autonome", "souverain", "open-weight", "quantique", "humanoïde"]):
            score += 5

        score = min(99, max(45, score))

        conn.execute(
            "UPDATE articles SET category = ?, score = ? WHERE id = ?",
            (detected_category, score, article["id"])
        )
        updated_count += 1

    conn.commit()
    conn.close()
    return updated_count

def generate_daily_digest():
    """Génère un résumé structuré des meilleures pépites de la veille IA du jour."""
    analyze_and_score_articles()
    top_articles = watch_db.get_articles(limit=8)
    
    if not top_articles:
        return {"id": 0, "title": "Synthèse indisponible", "content": "Aucune actualité disponible."}

    latest_date = (top_articles[0]["published_at"] or "")[:10]
    digest_lines = [
        f"# ⚡ Synthèse Exécutive de Veille IA ({latest_date})",
        "Sélection automatisée des percées technologiques majeures (Modèles, Agents, Robotique Humanoïde, Quantique & Souveraineté) :\n"
    ]

    for idx, art in enumerate(top_articles, 1):
        digest_lines.append(f"### {idx}. {art['title']} — ⭐ {art['score']}/100")
        digest_lines.append(f"**Source :** {art['source']} | **Catégorie :** {art['category']} | **Date :** {art['published_at'][:16]}")
        digest_lines.append(f"> {art['summary'] or 'Résumé indisponible.'}")
        digest_lines.append(f"🔗 [Consulter la source officielle]({art['link']})\n")

    content = "\n".join(digest_lines)
    title = f"Bulletin Exécutif IA du {latest_date}"
    
    digest_id = watch_db.save_digest(title, content)
    return {"id": digest_id, "title": title, "content": content}

if __name__ == "__main__":
    count = analyze_and_score_articles()
    print(f"Scoring et catégorisation effectués sur {count} articles.")
    digest = generate_daily_digest()
    print("Bulletin généré avec succès !")
