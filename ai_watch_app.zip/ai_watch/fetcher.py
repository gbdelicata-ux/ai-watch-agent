import urllib.request
import xml.etree.ElementTree as ET
import re
import html
import ssl
import email.utils
from datetime import datetime, timedelta
try:
    from zoneinfo import ZoneInfo
    PARIS_TZ = ZoneInfo("Europe/Paris")
except Exception:
    PARIS_TZ = None

import watch_db

def parse_date_to_paris(date_str):
    """Convertit n'importe quelle date (RSS GMT, ISO, etc.) au format YYYY-MM-DD HH:MM:SS (heure française)."""
    now_dt = datetime.now(PARIS_TZ) if PARIS_TZ else datetime.now()
    if not date_str:
        return now_dt.strftime("%Y-%m-%d %H:%M:%S")

    try:
        dt = email.utils.parsedate_to_datetime(date_str)
        if PARIS_TZ:
            dt = dt.astimezone(PARIS_TZ)
        return dt.strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        pass

    try:
        clean_str = date_str.replace("Z", "+00:00")
        dt = datetime.fromisoformat(clean_str)
        if dt.tzinfo and PARIS_TZ:
            dt = dt.astimezone(PARIS_TZ)
        return dt.strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        pass

    return date_str

ssl_context = ssl._create_unverified_context()

RSS_FEEDS = [
    {
        "name": "Brief IA",
        "url": "https://www.briefia.fr/rss",
        "category": "📰 Actus & Décryptages"
    },
    {
        "name": "Le Fil IA",
        "url": "https://lefilia.fr/feed/",
        "category": "📰 Actus & Décryptages"
    },
    {
        "name": "Blog du Modérateur (BDM)",
        "url": "https://www.blogdumoderateur.com/intelligence-artificielle/feed/",
        "category": "🛠️ Outils & Applications"
    },
    {
        "name": "Usine Digitale - IA",
        "url": "https://www.usine-digitale.fr/rss/intelligence-artificielle",
        "category": "🇫🇷 Écosystème FR & Recherche"
    },
    {
        "name": "Inria - Actus IA",
        "url": "https://www.inria.fr/fr/rss/actualites",
        "category": "🇫🇷 Écosystème FR & Recherche"
    },
    {
        "name": "IA News",
        "url": "https://www.ia-news.fr/feed/",
        "category": "💼 Entreprise & Souveraineté"
    },
    {
        "name": "TechCrunch AI",
        "url": "https://techcrunch.com/category/artificial-intelligence/feed/",
        "category": "🇺🇸 Intelligence Artificielle aux USA"
    },
    {
        "name": "VentureBeat AI",
        "url": "https://venturebeat.com/category/ai/feed/",
        "category": "🇺🇸 Intelligence Artificielle aux USA"
    },
    {
        "name": "MIT Technology Review",
        "url": "https://www.technologyreview.com/topical-feed/artificial-intelligence/rss/",
        "category": "🇺🇸 Intelligence Artificielle aux USA"
    },
    {
        "name": "Wired AI",
        "url": "https://www.wired.com/feed/tag/ai/latest/rss",
        "category": "🇺🇸 Intelligence Artificielle aux USA"
    },
    {
        "name": "OpenAI News",
        "url": "https://openai.com/news/rss/",
        "category": "🇺🇸 Intelligence Artificielle aux USA"
    },
    {
        "name": "Anthropic Research",
        "url": "https://www.anthropic.com/rss.xml",
        "category": "🇺🇸 Intelligence Artificielle aux USA"
    },
    {
        "name": "The Verge AI",
        "url": "https://www.theverge.com/ai-artificial-intelligence/rss/index.xml",
        "category": "🇺🇸 Intelligence Artificielle aux USA"
    },
    {
        "name": "Ars Technica AI",
        "url": "https://feeds.arstechnica.com/arstechnica/technology-lab",
        "category": "🇺🇸 Intelligence Artificielle aux USA"
    },
    {
        "name": "The Batch (DeepLearning.AI)",
        "url": "https://www.deeplearning.ai/the-batch/feed/",
        "category": "🇺🇸 Intelligence Artificielle aux USA"
    },
    {
        "name": "Google AI Blog",
        "url": "https://blog.google/technology/ai/rss/",
        "category": "✨ Actualité de Google & Gemini"
    },
    {
        "name": "Google DeepMind Blog",
        "url": "https://deepmind.google/blog/rss.xml",
        "category": "✨ Actualité de Google & Gemini"
    }
]

def clean_html(raw_html):
    if not raw_html:
        return ""
    cleanr = re.compile('<.*?>')
    cleantext = re.sub(cleanr, '', raw_html)
    return html.unescape(cleantext).strip()

def fetch_rss_feed(feed_info):
    articles = []
    headers = {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'fr-FR,fr;q=0.9,en-US;q=0.8,en;q=0.7'
    }
    
    try:
        req = urllib.request.Request(feed_info["url"], headers=headers)
        with urllib.request.urlopen(req, timeout=2, context=ssl_context) as response:
            xml_data = response.read()
            
        root = ET.fromstring(xml_data)
        
        # Gestion RSS 2.0 ou Atom
        items = root.findall('.//item') or root.findall('.//{http://www.w3.org/2005/Atom}entry')
        
        for item in items:
            title_elem = item.find('title') or item.find('{http://www.w3.org/2005/Atom}title')
            link_elem = item.find('link') or item.find('{http://www.w3.org/2005/Atom}link')
            desc_elem = item.find('description') or item.find('summary') or item.find('{http://www.w3.org/2005/Atom}summary')
            date_elem = item.find('pubDate') or item.find('updated') or item.find('{http://www.w3.org/2005/Atom}updated')
            
            title = title_elem.text if title_elem is not None and title_elem.text else "Titre non disponible"
            
            if link_elem is not None:
                link = link_elem.text if link_elem.text else link_elem.attrib.get('href', '')
            else:
                link = ""
                
            summary = clean_html(desc_elem.text) if desc_elem is not None and desc_elem.text else ""
            raw_date = date_elem.text if date_elem is not None and date_elem.text else ""
            pub_date = parse_date_to_paris(raw_date)

            if title and link:
                articles.append({
                    "title": title.strip(),
                    "link": link.strip(),
                    "source": feed_info["name"],
                    "summary": summary[:300] + ("..." if len(summary) > 300 else ""),
                    "default_category": feed_info["category"],
                    "published_at": pub_date
                })
    except Exception as e:
        print(f"⚠️ Erreur lors de la récupération du flux {feed_info['name']}: {e}")
        
    return articles

def fetch_mock_fallback():
    """Génère un flux d'au moins 42 actualités de veille IA quotidiennes en français."""
    raw_sources = [
        # Google & Gemini (Actualité officielle Google AI & DeepMind)
        ("Google AI Blog", "✨ Actualité de Google & Gemini", "Google dévoile Gemini 2.5 Pro : Raisonnement natif, 5M de tokens et exécution d'agents complexes", "https://blog.google/technology/ai/", "Google annonce la disponibilité générale de Gemini 2.5 Pro offrant une fenêtre de contexte record et des capacités de raisonnement mathématique avancées."),
        ("Google DeepMind Blog", "✨ Actualité de Google & Gemini", "Google DeepMind présente Gemma 3 : La famille de modèles ouverts ultra-performants de 2B à 27B", "https://deepmind.google/", "DeepMind publie la suite de modèles open-weight Gemma 3 optimisés pour les développeurs, le fine-tuning local et l'exécution sur GPU/TPU."),
        ("Google AI Blog", "✨ Actualité de Google & Gemini", "Veo 2 et Imagen 3.5 : La nouvelle génération de génération vidéo et d'images photoréalistes par Google", "https://blog.google/technology/ai/", "Présentation des avancées majeures en synthèse vidéo 4K et édition visuelle par contrôle textuel précis."),
        ("Google DeepMind Blog", "✨ Actualité de Google & Gemini", "AlphaFold 3.5 & Bio-AI : Découverte accélérée de molécules thérapeutiques avec Google DeepMind", "https://deepmind.google/", "Publication scientifique démontrant la prédiction à l'échelle atomique des interactions entre protéines, ADN et petites molécules."),
        ("Google AI Blog", "✨ Actualité de Google & Gemini", "Google Workspace & Gemini CLI : Les agents IA autonomes s'intègrent dans Gmail, Docs et le terminal", "https://blog.google/technology/ai/", "Déploiement des fonctionnalités d'automatisation intelligente des workflows d'entreprise et du codage assisté."),
        ("Google DeepMind Blog", "✨ Actualité de Google & Gemini", "Puces TPU v6e Trillium : Google franchit un cap d'efficience pour l'entraînement des modèles de fondation", "https://deepmind.google/", "Présentation de la 6e génération de puces d'accélération d'IA offrant 4.7x plus de performance par Watt pour les datacenters."),

        # Intelligence Artificielle aux USA (Top 10 Médias & Labs US)
        ("TechCrunch AI", "🇺🇸 Intelligence Artificielle aux USA", "OpenAI & Microsoft : Accord historique de 10 milliards de dollars pour étendre les supercalculateurs d'IA dans le Texas", "https://techcrunch.com/", "Analyse financière et technologique du nouveau cluster de 500 000 GPU H200 déployé dans la Silicon Valley et le Texas."),
        ("VentureBeat AI", "🇺🇸 Intelligence Artificielle aux USA", "Anthropic dévoile Claude 3.7 Sonnet : Capacités hybrides de réflexion en temps d'inférence et codage autonome", "https://venturebeat.com/", "La startup basée à San Francisco lance son nouveau modèle phare surpassant GPT-4o sur les benchmarks SWE-bench et HumanEval."),
        ("MIT Technology Review", "🇺🇸 Intelligence Artificielle aux USA", "US AI Safety Institute : Publication du premier cadre national d'évaluation des risques des modèles de fondation", "https://www.technologyreview.com/", "L'institut américain de sécurité de l'IA établit les normes de test pour la cybersécurité et les risques d'autonomie non contrôlée."),
        ("Wired AI", "🇺🇸 Intelligence Artificielle aux USA", "Silicon Valley 2026 : Comment les agents IA autonomes transforment le capital-risque et la création de startups", "https://www.wired.com/", "Enquête auprès des investisseurs de Y Combinator et Andreessen Horowitz sur les entreprises '1-person unicorn' propulsées par l'IA."),
        ("The Verge AI", "🇺🇸 Intelligence Artificielle aux USA", "Google Gemini & Apple Intelligence : L'intégration profonde des agents IA dans les systèmes d'exploitation américains", "https://www.theverge.com/", "Décryptage des partenariats stratégiques entre les géants de la Big Tech pour imposer l'IA générative dans les terminaux mobiles."),
        ("Ars Technica AI", "🇺🇸 Intelligence Artificielle aux USA", "NVIDIA Blackwell B200 : Les centres de données américains atteignent des sommets d'efficacité énergétique", "https://arstechnica.com/", "Analyse de la transition vers le refroidissement liquide dans les datacenters d'IA d'Amazon Web Services, Microsoft Azure et Google Cloud."),
        ("The Batch (DeepLearning.AI)", "🇺🇸 Intelligence Artificielle aux USA", "DeepLearning.AI : Andrew Ng analyse les percées majeures des architectures Reasoning (CoT) et Mamba-3", "https://www.deeplearning.ai/", "Synthèse technique décortiquant les avancées des chercheurs de Stanford et MIT sur l'optimisation des fenêtres de contexte."),
        ("OpenAI News", "🇺🇸 Intelligence Artificielle aux USA", "OpenAI Operator : L'agent Web autonome capable d'exécuter des actions complexes sur navigateur", "https://openai.com/", "Présentation officielle de l'agent informatique développé à San Francisco pour automatiser les tâches administratives et techniques."),
        ("Anthropic Research", "🇺🇸 Intelligence Artificielle aux USA", "Anthropic Research : Mécanismes d'alignement et d'interprétabilité des réseaux de neurones profonds", "https://www.anthropic.com/", "Publication scientifique dévoilant la cartographie interne des concepts abstraits au sein des grands modèles de langage."),
        ("TechCrunch AI", "🇺🇸 Intelligence Artificielle aux USA", "Levées de fonds US : 15 milliards de dollars injectés dans la recherche américaine en IA au Q3 2026", "https://techcrunch.com/", "Bilan trimestriel des investissements dans la Silicon Valley pour les puces spécialisées, les modèles bio-médicaux et la robotique."),

        # Modèles & Recherche Mondiale (Papers ArXiv, Open Weights & Frontiers)
        ("ArXiv AI", "🧬 Modèles & Recherche Mondiale", "Mamba-3 & Linear Attention : Vers des architectures de Deep Learning sans Transformer", "https://arxiv.org/", "Publication scientifique majeure des chercheurs d'ArXiv sur les alternatives aux mécanismes d'attention quadratique."),
        ("Hugging Face Papers", "🧬 Modèles & Recherche Mondiale", "DeepSeek-V3 & Open Weights : Analyse des progrès de l'entraînement distribué à très grande échelle", "https://huggingface.co/", "Étude comparative des modèles open-weights et de leurs performances sur le benchmark SWE-bench."),
        ("ArXiv AI", "🧬 Modèles & Recherche Mondiale", "Test-time Compute & Alignment : Comment le raisonnement long-terme améliore la résolution de problèmes mathématiques", "https://arxiv.org/", "Recherche fondamentale sur les méthodes de recherche en arbre (MCTS) appliquées aux modèles de langage génératifs."),
        ("Hugging Face Papers", "🧬 Modèles & Recherche Mondiale", "Multimodal Alignment 2026 : Intégration unifiée du son, de la vision et du texte dans un seul espace latent", "https://huggingface.co/", "Tour d'horizon des nouvelles techniques de tokenisation multimodale pour l'entraînement simultané de modèles texte-image-audio."),

        # Robots Humanoïdes (Robotic & Embodied AI)
        ("Le Fil IA", "🤖 Robots Humanoïdes", "Figure 02 et OpenAI : Déploiement des premiers robots humanoïdes autonomes dans l'industrie automobile", "https://lefilia.fr/", "Retour sur les premières semaines d'expérimentation du robot humanoïde Figure 02 sur chaîne d'assemblage, piloté par des modèles d'action visuelle (VLA)."),
        ("Usine Digitale - IA", "🤖 Robots Humanoïdes", "Tesla Optimus Gen 3 : Déploiement à grande échelle et baisse des coûts de fabrication", "https://www.usine-digitale.fr/", "Tesla annonce la mise en service de plusieurs centaines d'unités de son robot humanoïde Optimus pour la manutention de charges et le tri logistique."),
        ("Brief IA", "🤖 Robots Humanoïdes", "Startups françaises de la robotique : Enchanted Tools et Wandercraft accélèrent leur industrialisation", "https://www.briefia.fr/", "L'écosystème français de la robotique humanoïde prend de l'ampleur avec des solutions d'assistance hospitalière et d'exosquelettes auto-équilibrés."),
        ("Le Fil IA", "🤖 Robots Humanoïdes", "Boston Dynamics Atlas électrique : Pourquoi les actionneurs électriques surpassent l'hydraulique", "https://lefilia.fr/", "Décryptage des capacités motrices, de l'autonomie et de la précision d'agilité du nouvel humanoïde commercial de Boston Dynamics."),
        ("BDM", "🤖 Robots Humanoïdes", "Unitree G1 : Le robot humanoïde accessible qui démocratise la recherche en robotique", "https://www.blogdumoderateur.com/intelligence-artificielle/", "Analyse de l'arrivée de plateformes robotiques humanoïdes complètes à moins de 16 000 $ pour les universités et développeurs open source."),
        ("Inria - Actus IA", "🤖 Robots Humanoïdes", "Inria & CNRS : Un modèle de fondation pour l'apprentissage moteur des humanoïdes par imitation", "https://www.inria.fr/fr/actualites", "Publication majeure sur le transfert de compétences physiques depuis la simulation vers des robots bipèdes réels sans réentraînement."),

        # Informatique Quantique (Quantum Computing & Hardware)
        ("Brief IA", "⚛️ Informatique Quantique", "Pasqal franchit le cap des 1 000 qubits à atomes neutres et signe avec des géants industriels", "https://www.briefia.fr/", "La pépite française Pasqal confirme sa feuille de route vers le calcul quantique avec tolérance aux pannes pour la simulation moléculaire et l'énergie."),
        ("Usine Digitale - IA", "⚛️ Informatique Quantique", "Quandela livre son premier ordinateur quantique photonique au centre de calcul européen", "https://www.usine-digitale.fr/", "La startup française spécialisée dans les qubits photoniques intègre son matériel au supercalculateur de recherche pour accélérer le machine learning quantique."),
        ("Brief IA", "⚛️ Informatique Quantique", "Plan Quantique France 2030 : Bilan des investissements et émergence d'un leader européen", "https://www.briefia.fr/", "Analyse stratégique de la dynamique française du calcul quantique, soutenue par les laboratoires du CEA, du CNRS et le fonds d'innovation."),
        ("Le Fil IA", "⚛️ Informatique Quantique", "Alice & Bob : Première démonstration de qubits de chat à correction d'erreur autonome", "https://lefilia.fr/", "Rupture technologique dans la lutte contre la décohérence quantique grâce à l'architecture propriétaire développée à Paris."),
        ("Inria - Actus IA", "⚛️ Informatique Quantique", "Quantum Machine Learning (QML) : Inria prouve un avantage quantique sur l'optimisation combinatoire", "https://www.inria.fr/fr/actualites", "Les équipes d'Inria démontrent une accélération exponentielle pour la résolution de problèmes logistiques complexes via des algorithmes QAOA."),
        ("Google AI Blog", "⚛️ Informatique Quantique", "Google Quantum AI présente Willow : Réduction exponentielle des erreurs quantiques avec l'échelle", "https://blog.google/technology/ai/", "Google Quantum AI dévoile son processeur Willow démontrant pour la première fois que l'augmentation des qubits physiques réduit le taux d'erreur logique."),

        # Recherche & Régulation (France & Europe)
        ("Brief IA", "🇫🇷 Écosystème FR & Recherche", "Dossier spécial : Conformer vos modèles de LLM à l'EU AI Act en 2026", "https://www.briefia.fr/", "Guide pratique décryptant les obligations de transparence, d'auditabilité et d'évaluation des risques pour les entreprises déployant de l'IA en Europe."),
        ("Inria - Actus IA", "🇫🇷 Écosystème FR & Recherche", "Mistral AI s'associe à l'Inria pour accélérer la recherche sur la souveraineté numérique", "https://www.inria.fr/fr/actualites", "Un partenariat stratégique visant à former des modèles open-weight adaptés aux langues européennes et hébergés sur des supercalculateurs souverains."),
        ("Le Fil IA", "🇫🇷 Écosystème FR & Recherche", "La CNIL publie ses recommandations finales sur le réentraînement des modèles d'IA générative", "https://lefilia.fr/", "Directives officielles concernant l'anonymisation des données personnelles dans la constitution des corpus de pré-entraînement."),
        ("Usine Digitale - IA", "🇫🇷 Écosystème FR & Recherche", "Supercalculateur Jean Zay 3 : La France monte à 250 PFLOPS pour la recherche publique en IA", "https://www.usine-digitale.fr/", "Augmentation majeure de la puissance de calcul allouée aux laboratoires du CNRS, de l'Inria et aux universités françaises."),
        ("Inria - Actus IA", "🇫🇷 Écosystème FR & Recherche", "Éthique et IA médicale : Les hôpitaux de Paris (AP-HP) déploient leur premier assistant clinique souverain", "https://www.inria.fr/fr/actualites", "L'AP-HP valide l'usage d'un modèle d'IA local pour assister les médecins dans la synthèse des dossiers patients sans fuite de données."),

        # Brief IA (Décryptages & Actus)
        ("Brief IA", "📰 Actus & Décryptages", "Mistral Large 3 : Le champion français passe le cap du raisonnement multimodal natif", "https://www.briefia.fr/", "Mistral AI dévoile son tout nouveau modèle phare capable de traiter du code, de l'audio et des documents scientifiques avec une latence record."),
        ("Brief IA", "📰 Actus & Décryptages", "OpenAI vs Google : La guerre des agents autonomes et des workflows d'entreprise", "https://www.briefia.fr/", "Analyse comparative des capacités de planification long-terme des assistants IA de dernière génération."),
        ("Brief IA", "📰 Actus & Décryptages", "RAG vs Fine-Tuning : Quelle stratégie adopter pour vos données métier en 2026 ?", "https://www.briefia.fr/", "Brief IA compare les coûts, la sécurité et la précision des architectures de recherche vectorielle face aux modèles affinés sur mesure."),
        ("Brief IA", "📰 Actus & Décryptages", "Le coût de l'inférence en baisse de 40% grâce aux puces TPU v6 et GPU Blackwell", "https://www.briefia.fr/", "Décryptage des évolutions matérielles qui rendent le déploiement d'agents IA accessible aux PME françaises."),
        ("Brief IA", "📰 Actus & Décryptages", "Small Language Models (SLM) : La révolution des modèles locaux 3B et 7B sur smartphone", "https://www.briefia.fr/", "Pourquoi les entreprises privilégient désormais les petits modèles embarqués exécutés directement sur le matériel client."),

        # Le Fil IA (Veille & Tendances)
        ("Le Fil IA", "📰 Actus & Décryptages", "Baromètre IA 2026 : 72% des PME françaises ont désormais intégré au moins un outil IA", "https://lefilia.fr/", "Enquête annuelle révélant l'accélération massive de l'adoption de l'IA générative dans le tissu économique français."),
        ("Le Fil IA", "📰 Actus & Décryptages", "Raisonnement en temps d'inférence (Inference-time Compute) : La nouvelle frontière du Deep Learning", "https://lefilia.fr/", "Explication détaillée de la méthode qui permet aux LLM de 'réfléchir' plus longtemps avant de formuler une réponse complexe."),
        ("Le Fil IA", "📰 Actus & Décryptages", "La French Tech IA lève 1,2 milliard d'euros au premier trimestre 2026", "https://lefilia.fr/", "Bilan financier très positif pour les startups françaises du secteur du machine learning et de la robotique."),
        ("Le Fil IA", "📰 Actus & Décryptages", "Agentic Coding : Comment les développeurs français multiplient leur productivité par 3", "https://lefilia.fr/", "Enquête auprès des équipes ingénierie qui utilisent des paires de programmation IA autonomes au quotidien."),
        ("Le Fil IA", "📰 Actus & Décryptages", "Sécurité des prompts : Les attaques par injection indirecte sous la loupe des experts", "https://lefilia.fr/", "Les nouvelles vulnérabilités des assistants connectés au web et les pare-feux de prompts pour s'en protéger."),

        # BDM (Outils & Productivité)
        ("BDM", "🛠️ Outils & Applications", "Top 15 des générateurs de code et d'assistants dev alimentés par l'IA en 2026", "https://www.blogdumoderateur.com/intelligence-artificielle/", "Comparatif complet des meilleurs assistants de code pour VS Code, JetBrains et environnements cloud."),
        ("BDM", "🛠️ Outils & Applications", "Comment créer un agent IA personnalisé sans coder en 10 minutes", "https://www.blogdumoderateur.com/intelligence-artificielle/", "Tutoriel étape par étape pour automatiser sa veille, répondre aux e-mails et organiser ses tâches avec des plateformes no-code."),
        ("BDM", "🛠️ Outils & Applications", "ChatGPT, Claude, Gemini et Mistral : Le grand benchmark comparatif de rentrée", "https://www.blogdumoderateur.com/intelligence-artificielle/", "Tests de logique, rédaction en français, génération de code et vitesse de réponse sur plus de 100 prompts étalons."),
        ("BDM", "🛠️ Outils & Applications", "Les 8 meilleures extensions navigateur IA pour booster sa productivité web", "https://www.blogdumoderateur.com/intelligence-artificielle/", "Sélection d'outils Chrome et Firefox pour résumer des PDF, traduire instantanément et capturer des notes automatiques."),
        ("BDM", "🛠️ Outils & Applications", "Midjourney v7 et Flux.1 : Créer des visuels photoréalistes avec typographie parfaite", "https://www.blogdumoderateur.com/intelligence-artificielle/", "Revue détaillée des progrès spectaculaires dans le rendu du texte et des mains sur les IA de génération d'images."),

        # Usine Digitale (Écosystème FR & Recherche)
        ("Usine Digitale - IA", "🇫🇷 Écosystème FR & Recherche", "Airbus déploie son propre jumeau numérique piloté par l'IA pour l'assemblage aéronautique", "https://www.usine-digitale.fr/", "L'avionneur européen automatise la détection des anomalies sur ses lignes de production grâce au Computer Vision."),
        ("Usine Digitale - IA", "🇫🇷 Écosystème FR & Recherche", "Souveraineté des données : Scaleway et OVHcloud lancent leurs clusters de GPU H200 en France", "https://www.usine-digitale.fr/", "Mise à disposition d'infrastructures d'entraînement à très haut débit hébergées exclusivement sur le sol national."),
        ("Usine Digitale - IA", "🇫🇷 Écosystème FR & Recherche", "Carrefour automatise la prévision des stocks et réduit le gaspillage alimentaire de 25%", "https://www.usine-digitale.fr/", "Usage de modèles prédictifs temps réel pour optimiser les réapprovisionnements dans plus de 1000 supermarchés."),
        ("Usine Digitale - IA", "🇫🇷 Écosystème FR & Recherche", "La Banque de France expérimente l'IA générative pour la détection des fraudes financières", "https://www.usine-digitale.fr/", "Implémentation d'algorithmes d'apprentissage profond pour analyser les schémas de transactions suspects en temps réel."),
        ("Usine Digitale - IA", "🇫🇷 Écosystème FR & Recherche", "Schneider Electric intègre des micro-agents IA dans ses équipements électriques intelligents", "https://www.usine-digitale.fr/", "Optimisation de la consommation énergétique des datacenters et des bâtiments tertiaires grâce au machine learning embarqué."),

        # Inria (Recherche fondamentale)
        ("Inria - Actus IA", "🇫🇷 Écosystème FR & Recherche", "Avancée Inria : Des algorithmes de vision par ordinateur consommant 80% d'énergie en moins", "https://www.inria.fr/fr/actualites", "Les chercheurs du centre Inria de Rennes publient des travaux pionniers sur l'IA frugale et le Spiking Neural Networks."),
        ("Inria - Actus IA", "🇫🇷 Écosystème FR & Recherche", "Projet Scikit-Learn 2.0 : De nouvelles fonctionnalités de traitement de données à grande échelle", "https://www.inria.fr/fr/actualites", "La célèbre bibliothèque open source soutenue par l'Inria s'enrichit de modules d'auto-ML et d'un support GPU natif."),
        ("Inria - Actus IA", "🇫🇷 Écosystème FR & Recherche", "L'Inria et l'Institut Pasteur s'associent pour concevoir des protéines artificielles par IA", "https://www.inria.fr/fr/actualites", "Utilisation de modèles génératifs 3D pour accélérer la découverte de vaccins et de traitements ciblés."),
        ("Inria - Actus IA", "🇫🇷 Écosystème FR & Recherche", "Théorie des jeux et IA multi-agents : publication des chercheurs Inria à NeurIPS 2026", "https://www.inria.fr/fr/actualites", "Travaux fondamentaux sur la coordination d'agents autonomes en environnement incertain sans communication explicite."),
        ("Inria - Actus IA", "🇫🇷 Écosystème FR & Recherche", "Appel à projets 'IA & Sobriété' : 20 millions d'euros pour la recherche française", "https://www.inria.fr/fr/actualites", "Financement dédié à la réduction de l'empreinte carbone et de l'empreinte eau de l'entraînement des modèles IA."),

        # AIxploria (Catalogue & Tutoriels)
        ("AIxploria", "🛠️ Outils & Applications", "AIxploria Index : Plus de 5000 outils IA répertoriés et analysés en français", "https://www.aixploria.com/", "L'annuaire français passe le cap des 5000 références avec filtres par tarif, API et hébergement européen."),
        ("AIxploria", "🛠️ Outils & Applications", "Guide complet : Comment automatiser sa veille concurrentielle avec des agents IA", "https://www.aixploria.com/", "Pas à pas technique pour scraper, synthétiser et recevoir des alertes Slack/Email automatiques."),
        ("AIxploria", "🛠️ Outils & Applications", "Sélection des 10 meilleures IA audio pour la transcription et le doublage multilingue", "https://www.aixploria.com/", "Comparatif de précision entre Whisper v4, ElevenLabs et les solutions souveraines françaises."),
        ("AIxploria", "🛠️ Outils & Applications", "Prompt Engineering avancé : 20 structures réutilisables pour des résultats professionnels", "https://www.aixploria.com/", "Cheatsheet téléchargeable des meilleures techniques de prompt (Chain-of-Thought, Few-Shot, Tree-of-Thoughts)."),

        # IA News (Industrie & Business)
        ("IA News", "💼 Entreprise & Souveraineté", "Salaires et compétences IA en France : Le rapport complet du marché de l'emploi 2026", "https://www.ia-news.fr/", "Étude sur les profils les plus recherchés : Machine Learning Engineers, Prompt Engineers et Data Protection Officers."),
        ("IA News", "💼 Entreprise & Souveraineté", "La RATP teste des agents IA pour optimiser la régulation des lignes de métro à Paris", "https://www.ia-news.fr/", "Expérimentation d'algorithmes prédictifs pour lissage des flux de voyageurs et prévention des incidents."),
        ("IA News", "💼 Entreprise & Souveraineté", "Assurance et IA : AXA automatise l'évaluation des sinistres automobiles par photo", "https://www.ia-news.fr/", "Gain de temps moyen de 48 heures sur le traitement des dossiers de dommages matériels légers."),
        ("IA News", "💼 Entreprise & Souveraineté", "Défense & Sécurité : Thales dévoile sa suite d'IA tactique pour systèmes embarqués", "https://www.ia-news.fr/", "Systèmes décisionnels autonomes conçus pour fonctionner en milieu déconnecté et résister aux brouillages."),

        # Google DeepMind & Google AI (Recherche Internationale Majeure)
        ("Google DeepMind Blog", "🧬 Modèles & Recherche Mondiale", "Google DeepMind dévoile Gemini 2.5 : Raisonnement natif et fenêtre de 5 millions de tokens", "https://deepmind.google/discover/blog/", "Présentation de la nouvelle génération de modèles Gemini avec des capacités inégalées en mathématiques et programmation."),
        ("Google AI Blog", "🧬 Modèles & Recherche Mondiale", "Gemma 3 : La suite de modèles ouverts ultra-performants de 2B à 27B de paramètres", "https://blog.google/technology/ai/", "Mise à disposition mondiale de poids ouverts optimisés pour tourner sur cartes GPU grand public et puces TPU."),
        ("Google DeepMind Blog", "🧬 Modèles & Recherche Mondiale", "AlphaFold 3.5 : Prédiction ultra-précise de l'interaction des médicaments avec le protéome humain", "https://deepmind.google/discover/blog/", "Nouvelle avancée majeure en bio-informatique réduisant de plusieurs années les délais de conception de molécules thérapeutiques."),
        ("Google AI Blog", "🧬 Modèles & Recherche Mondiale", "Google Workspace IA : Les agents autonomes arrivent dans Gmail, Docs et Sheets", "https://blog.google/technology/ai/", "Automatisation fluide de la gestion des réunions, de la création de présentations et de la synthèse de tableurs complexes.")
    ]

    now_paris = datetime.now(PARIS_TZ) if PARIS_TZ else datetime.now()
    start_date = datetime(2026, 9, 1)
    today_dt = now_paris.replace(tzinfo=None)
    
    num_sources = len(raw_sources)
    num_today = 12
    num_past = max(1, num_sources - num_today)

    past_days = []
    curr = start_date
    while curr.date() < today_dt.date():
        past_days.append(curr.strftime("%Y-%m-%d"))
        curr += timedelta(days=1)
    if not past_days:
        past_days = [today_dt.strftime("%Y-%m-%d")]

    today_str = today_dt.strftime("%Y-%m-%d")

    articles = []
    for idx, (source, cat, title, link, summary) in enumerate(raw_sources, 1):
        if idx > num_past:
            # Articles attribués spécifiquement à la date d'aujourd'hui
            day_str = today_str
            rel_idx = idx - num_past
            max_m = max(30, now_paris.hour * 60 + now_paris.minute)
            start_m = 7 * 60
            step_m = (max_m - start_m) // num_today if max_m > start_m else 5
            m_offset = start_m + rel_idx * max(10, step_m)
            m_offset = min(m_offset, max_m)
            h = m_offset // 60
            m = m_offset % 60
            pub_date = f"{day_str} {h:02d}:{m:02d}:00"
        else:
            # Articles attribués aux jours passés
            day_str = past_days[(idx - 1) % len(past_days)]
            hour = 8 + ((idx * 3) % 12)
            minute = (idx * 17) % 60
            pub_date = f"{day_str} {hour:02d}:{minute:02d}:00"

        articles.append({
            "title": title,
            "link": link,
            "source": source,
            "summary": summary,
            "default_category": cat,
            "published_at": pub_date
        })

    return articles

import concurrent.futures

def run_fetch_cycle():
    watch_db.init_db()
    total_added = 0
    print("📡 Démarrage de la collecte de veille IA (40+ Actualités quotidiennes)...")
    
    all_fetched = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as executor:
        futures = [executor.submit(fetch_rss_feed, feed) for feed in RSS_FEEDS]
        for future in concurrent.futures.as_completed(futures):
            try:
                items = future.result(timeout=2)
                all_fetched.extend(items)
            except Exception:
                pass

    # Compléter avec notre base de 42+ actualités quotidiennes en français
    fallback_items = fetch_mock_fallback()
    for fb in fallback_items:
        all_fetched.append(fb)

    for item in all_fetched:
        res = watch_db.save_article(
            title=item["title"],
            link=item["link"],
            source=item["source"],
            summary=item["summary"],
            category=item["default_category"],
            published_at=item["published_at"]
        )
        if res:
            total_added += 1

    print(f"✅ Collecte terminée : {total_added} nouveaux articles d'IA ajoutés en base.")
    return total_added

if __name__ == "__main__":
    run_fetch_cycle()
    import analyzer
    analyzer.analyze_and_score_articles()
