"""
WSGI Application adapter pour le déploiement sur PythonAnywhere.
"""
import os
import json
import urllib.parse
from datetime import datetime
try:
    from zoneinfo import ZoneInfo
    PARIS_TZ = ZoneInfo("Europe/Paris")
except Exception:
    PARIS_TZ = None

def get_paris_time_str():
    if PARIS_TZ:
        return datetime.now(PARIS_TZ).strftime("%H:%M:%S")
    return datetime.now().strftime("%H:%M:%S")

import time

import watch_db
import fetcher
import analyzer

BASE_DIR = os.path.dirname(__file__)

sync_state = {
    "last_sync_time": get_paris_time_str(),
    "last_sync_timestamp": time.time(),
    "interval_seconds": 3600,
    "is_syncing": False,
    "total_processed": 0
}

watch_db.init_db()

def application(environ, start_response):
    path = environ.get('PATH_INFO', '/')
    method = environ.get('REQUEST_METHOD', 'GET').upper()
    query_string = environ.get('QUERY_STRING', '')
    query_params = urllib.parse.parse_qs(query_string)

    # 1. Favicon & Apple touch icons
    if path == '/favicon.ico' or 'apple-touch-icon' in path:
        start_response('204 No Content', [('Content-Type', 'text/plain')])
        return [b'']

    # 2. Page d'accueil & SPA fallback
    if method == 'GET' and (path == '/' or path == '/index.html' or not path.startswith(('/api/', '/static/'))):
        template_path = os.path.join(BASE_DIR, 'templates', 'index.html')
        if os.path.exists(template_path):
            with open(template_path, 'rb') as f:
                content = f.read()
            start_response('200 OK', [('Content-Type', 'text/html; charset=utf-8')])
            return [content]

    # 3. Fichiers statiques
    if method == 'GET' and path.startswith('/static/'):
        rel_path = path[len('/static/'):]
        file_path = os.path.join(BASE_DIR, 'static', rel_path)
        if os.path.exists(file_path):
            content_type = 'text/css; charset=utf-8' if file_path.endswith('.css') else 'application/javascript; charset=utf-8'
            with open(file_path, 'rb') as f:
                content = f.read()
            start_response('200 OK', [('Content-Type', content_type)])
            return [content]

    # 4. API Endpoints GET
    if method == 'GET' and path == '/api/articles':
        category = query_params.get('category', ['ALL'])[0]
        search = query_params.get('search', [None])[0]
        favorites_only = (category == 'FAVORITES')
        articles = watch_db.get_articles(
            category=category if not favorites_only else None,
            search=search,
            favorites_only=favorites_only
        )
        body = json.dumps({"status": "success", "articles": articles}).encode('utf-8')
        start_response('200 OK', [('Content-Type', 'application/json; charset=utf-8'), ('Cache-Control', 'no-cache, no-store, must-revalidate')])
        return [body]

    if method == 'GET' and path == '/api/status':
        elapsed = time.time() - sync_state["last_sync_timestamp"]
        remaining = max(0, int(sync_state["interval_seconds"] - elapsed))
        total_articles = len(watch_db.get_articles(limit=500))
        payload = {
            "status": "success",
            "last_sync_time": sync_state["last_sync_time"],
            "interval_seconds": sync_state["interval_seconds"],
            "next_sync_in_seconds": remaining,
            "is_syncing": sync_state["is_syncing"],
            "total_articles": total_articles
        }
        body = json.dumps(payload).encode('utf-8')
        start_response('200 OK', [('Content-Type', 'application/json; charset=utf-8'), ('Cache-Control', 'no-cache, no-store, must-revalidate')])
        return [body]

    # 5. API Endpoints POST
    if method == 'POST' and path == '/api/fetch':
        sync_state["is_syncing"] = True
        added_count = fetcher.run_fetch_cycle()
        analyzer.analyze_and_score_articles()
        sync_state["last_sync_time"] = get_paris_time_str()
        sync_state["last_sync_timestamp"] = time.time()
        sync_state["is_syncing"] = False
        body = json.dumps({"status": "success", "count": added_count}).encode('utf-8')
        start_response('200 OK', [('Content-Type', 'application/json; charset=utf-8')])
        return [body]

    if method == 'POST' and path == '/api/digest':
        digest = analyzer.generate_daily_digest()
        body = json.dumps({"status": "success", "digest": digest}).encode('utf-8')
        start_response('200 OK', [('Content-Type', 'application/json; charset=utf-8')])
        return [body]

    if method == 'POST' and path.startswith('/api/articles/') and path.endswith('/favorite'):
        try:
            article_id = int(path.split('/')[3])
            watch_db.toggle_favorite(article_id)
            body = json.dumps({"status": "success"}).encode('utf-8')
            start_response('200 OK', [('Content-Type', 'application/json; charset=utf-8')])
            return [body]
        except (ValueError, IndexError):
            start_response('400 Bad Request', [('Content-Type', 'application/json')])
            return [b'{"status":"error"}']

    start_response('404 Not Found', [('Content-Type', 'application/json')])
    return [b'{"status":"error","message":"Not found"}']
