"""
WSGI Application adapter pour le déploiement sur PythonAnywhere.
"""
import wsgi

application = wsgi.application
