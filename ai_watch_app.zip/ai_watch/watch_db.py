import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(__file__), "ai_watch.db")

def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_connection()
    cursor = conn.cursor()
    
    # Table des articles de veille
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS articles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT UNIQUE NOT NULL,
            link TEXT NOT NULL,
            source TEXT NOT NULL,
            summary TEXT,
            category TEXT DEFAULT 'Général IA',
            score INTEGER DEFAULT 50,
            published_at TEXT,
            is_favorite INTEGER DEFAULT 0,
            read_later INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    # Table des synthèses / bulletins de veille
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS digests (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            content TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    conn.commit()
    conn.close()

def save_article(title, link, source, summary="", category="Général IA", score=50, published_at=""):
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute('''
            INSERT INTO articles (title, link, source, summary, category, score, published_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (title, link, source, summary, category, score, published_at))
        conn.commit()
        inserted_id = cursor.lastrowid
        conn.close()
        return inserted_id
    except sqlite3.IntegrityError:
        # Article déjà présent
        conn.close()
        return None

def get_articles(category=None, search=None, favorites_only=False, limit=100):
    conn = get_connection()
    # Veille active à partir du 1er septembre 2026
    query = "SELECT * FROM articles WHERE (published_at >= '2026-09-01' OR published_at LIKE '%Sep 2026%')"
    params = []

    if category and category != 'ALL':
        query += " AND category = ?"
        params.append(category)

    if search:
        query += " AND (title LIKE ? OR summary LIKE ? OR source LIKE ?)"
        search_param = f"%{search}%"
        params.extend([search_param, search_param, search_param])

    if favorites_only:
        query += " AND is_favorite = 1"

    query += " ORDER BY published_at DESC, score DESC LIMIT ?"
    params.append(limit)

    cursor = conn.execute(query, params)
    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]

def toggle_favorite(article_id):
    conn = get_connection()
    conn.execute("UPDATE articles SET is_favorite = NOT is_favorite WHERE id = ?", (article_id,))
    conn.commit()
    conn.close()

def save_digest(title, content):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO digests (title, content) VALUES (?, ?)", (title, content))
    conn.commit()
    digest_id = cursor.lastrowid
    conn.close()
    return digest_id

def get_digests(limit=10):
    conn = get_connection()
    cursor = conn.execute("SELECT * FROM digests ORDER BY created_at DESC LIMIT ?", (limit,))
    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]

if __name__ == "__main__":
    init_db()
    print("Base SQLite d'Agent de Veille IA initialisée.")
