import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(__file__), "ai_watch.db")

def get_connection():
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    try:
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.execute("PRAGMA synchronous=NORMAL;")
    except Exception:
        pass
    return conn

def init_db():
    conn = get_connection()
    cursor = conn.cursor()
    
    # Table des articles de veille
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS articles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT UNIQUE NOT NULL,
            link TEXT NOT NULL,
            source TEXT NOT NULL,
            summary TEXT,
            category TEXT DEFAULT 'Général IA',
            score INTEGER DEFAULT 50,
            published_at TEXT,
            is_favorite INTEGER DEFAULT 0,
            read_later INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    # Index de performance pour tri chronologique et filtrage instantané
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_articles_pub_score ON articles (published_at DESC, score DESC)')
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_articles_category ON articles (category)')

    # Table des synthèses / bulletins de veille
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS digests (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            content TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    conn.commit()
    conn.close()

def save_article(title, link, source, summary="", category="Général IA", score=50, published_at=""):
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute('''
            INSERT INTO articles (title, link, source, summary, category, score, published_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (title, link, source, summary, category, score, published_at))
        conn.commit()
        inserted_id = cursor.lastrowid
        conn.close()
        return inserted_id
    except sqlite3.IntegrityError:
        cursor.execute('''
            UPDATE articles SET published_at = ?, summary = ?, link = ?, source = ?, category = ? WHERE title = ?
        ''', (published_at, summary, link, source, category, title))
        conn.commit()
        conn.close()
        return None

def needs_daily_refresh(today_str):
    """Vérifie si la base possède déjà les actualités du jour (today_str au format YYYY-MM-DD)."""
    try:
        conn = get_connection()
        cursor = conn.execute(
            "SELECT COUNT(*) as cnt FROM articles WHERE published_at LIKE ?",
            (f"{today_str}%",)
        )
        row = cursor.fetchone()
        conn.close()
        return (row["cnt"] if row else 0) < 8
    except Exception:
        return True

def get_articles(category=None, search=None, favorites_only=False, limit=250):
    conn = get_connection()
    # Veille active à partir du 1er septembre 2026
    query = "SELECT * FROM articles WHERE (published_at >= '2026-09-01' OR published_at LIKE '%Sep 2026%' OR published_at LIKE '%Oct 2026%')"
    params = []

    if category and category != 'ALL':
        query += " AND category = ?"
        params.append(category)

    if search:
        query += " AND (title LIKE ? OR summary LIKE ? OR source LIKE ?)"
        search_param = f"%{search}%"
        params.extend([search_param, search_param, search_param])

    if favorites_only:
        query += " AND is_favorite = 1"

    query += " ORDER BY published_at DESC, score DESC LIMIT ?"
    params.append(limit)

    cursor = conn.execute(query, params)
    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]

def get_category_counts(today_str=""):
    """Retourne les compteurs d'articles par catégorie, favoris et articles du jour."""
    conn = get_connection()
    base_where = "(published_at >= '2026-09-01' OR published_at LIKE '%Sep 2026%' OR published_at LIKE '%Oct 2026%')"
    cursor = conn.execute(f"SELECT category, COUNT(*) as cnt FROM articles WHERE {base_where} GROUP BY category")
    counts = {row["category"]: row["cnt"] for row in cursor.fetchall()}

    total_row = conn.execute(f"SELECT COUNT(*) as cnt FROM articles WHERE {base_where}").fetchone()
    counts["ALL"] = total_row["cnt"] if total_row else 0

    fav_row = conn.execute(f"SELECT COUNT(*) as cnt FROM articles WHERE {base_where} AND is_favorite = 1").fetchone()
    counts["FAVORITES"] = fav_row["cnt"] if fav_row else 0

    if today_str:
        today_row = conn.execute("SELECT COUNT(*) as cnt FROM articles WHERE published_at LIKE ?", (f"{today_str}%",)).fetchone()
        counts["TODAY"] = today_row["cnt"] if today_row else 0

    sources_row = conn.execute(f"SELECT COUNT(DISTINCT source) as cnt FROM articles WHERE {base_where}").fetchone()
    counts["SOURCES_COUNT"] = sources_row["cnt"] if sources_row else 0

    conn.close()
    return counts

def toggle_favorite(article_id):
    conn = get_connection()
    conn.execute("UPDATE articles SET is_favorite = NOT is_favorite WHERE id = ?", (article_id,))
    conn.commit()
    conn.close()

def save_digest(title, content):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO digests (title, content) VALUES (?, ?)", (title, content))
    conn.commit()
    digest_id = cursor.lastrowid
    conn.close()
    return digest_id

def get_digests(limit=10):
    conn = get_connection()
    cursor = conn.execute("SELECT * FROM digests ORDER BY created_at DESC LIMIT ?", (limit,))
    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]

if __name__ == "__main__":
    init_db()
    print("Base SQLite d'Agent de Veille IA initialisée et optimisée (WAL + Index).")
